var WindowSettings = {
	aniDuration: 300,
	minWidth: 332,
	minHeight: 547,
	width: 950,
	height: 547,
	center: true,
	debug: true
}

$(function(){
	//添加窗口Resize
	//LxExt.Dialog.setBorderDrag(true);
	//LxExt.Dialog.borderDrag($("#MyBody"),$("#MyWindow"),5);
	//设置最小大小
	LxExt.Dialog.setMinimumSize(WindowSettings.minWidth, WindowSettings.minHeight);
	//窗口居中
	WindowSettings.center && LxExt.Dialog.centerWnd();
	//设置窗口的大小
	LxExt.Dialog.initWndWH(WindowSettings.width, WindowSettings.height);
	//LxExt.Dialog.updateClientSize($("#MyBody"),30);
	//设置窗口标题栏目可移动
	LxExt.Dialog.dragRegion($('header'));
	//添加 最小化，关闭事件
	var _max = function() {
		if($('body').hasClass('max')) {
			$('body').removeClass('max');
			LxExt.Dialog.showNormal();
		} else {
			$('body').addClass('max');
			$('#lx').hide().addClass('full');

			setTimeout(function() {
				$('#lx').show();
			}, 100);
			LxExt.Dialog.showMaximized();
		}
		(window.sizeToggle || $.noop)();
	}
	$("#w-max").click(_max);
	$('header').dblclick(_max);
	$("#w-min").click(function(){
		LxExt.Dialog.showMinimized();
	});
	$("#w-close").click(function(){
		var lx = $('#lx');
		if(lx.length == 1) {
			lx.fadeOut(WindowSettings.aniDuration, LxExt.Dialog.closeWnd);
		} else {
			LxExt.Dialog.closeWnd();
		}
	});
	$('#w-toggle').click(function() {
		var lx = $('#lx');
		if(lx.hasClass('full')) {
			lx.removeClass('full');
			if($('body').hasClass('max')) {
				_max();
			} 
		} else {
			lx.addClass('full');
		}
	});
	
	// var _gridResize = function(cells) {
	// 	cells.each(function() {
	// 		var width = $(this).width();
	// 		$(this).find('p:first').width(width);
	// 	});
	// }
	// var _resizeTimer;
	// $('#network-grid, #local-grid').colResizable({
	// 	liveDrag: true,
	// 	draggingClass: 'dragging',
	// 	onDrag: function(e) {
	// 		_gridResize($(e.currentTarget).find("th"));
	// 	},
	// 	onResize: function(e){
	// 		//_gridResize($(e.currentTarget).find("th"));
	// 	}
	// });
	// _gridResize($('#network-grid th, #local-grid th'));
	// $(window).resize(function() {
	// 	_gridResize($('#network-grid th, #local-grid th'));
	// });

	
});

//Debug 设置
if(WindowSettings.debug) {
	$(window).keydown(function(event) {
		if(event.keyCode == 116) {
			location.reload();
		}
	});
}

var Page = new function() {
	var init = function() {
		
	}

	this.escapeHTML = function(string) {
		var entityMap = {
			"&": "&amp;",
			"<": "&lt;",
			">": "&gt;",
			'"': '&quot;',
			"'": '&#39;',
			"/": '&#x2F;'
		};

		return String(string).replace(/[&<>"'\/]/g, function (s) {
			return entityMap[s];
		});
	}

	this.loadScript = function(options) {
		if(typeof options.test == 'string') {
			options.test = window[options.test]
		}
		if(!options.test) {
			var script = document.createElement('script');
			var onload = options.onload || options.onLoad || $.noop;
			script.setAttribute('type', 'text/javascript');
			script.setAttribute('src', options.src);
			if('onload' in script) {
				script.onload = onload;
			} else if('onreadystatechange' in script) {
				script.onreadystatechange = function() {
					if(this.readyState=='loaded' || this.readyState=='complete') {
						onload.call(this);
					}
				}
			}
			document.getElementsByTagName('head')[0].appendChild(script);
			$('head:first').append(script);
		}
	}

	init.call(this);
}();


Page.contextMenu = new function() {
	this.setup = function(menu) {
		// if(menu.parent().get(0).tagName != 'body') {
		// 	menu.appendTo(document.body);
		// }
		menu.css('position', 'fixed');
	},

	this.show = function(event, src, menu, reference) {
		var o = 1;
		var position = {
			'left': event.pageX - o,
			'top': event.pageY - o
		}
		var size = menu.size();
		var docSize = {
			'width': document.documentElement.clientWidth,
			'height': document.documentElement.clientHeight
		}
		var map = {
			'left': 'width',
			'top': 'height'
		}
		var attr;
		if(reference) {
			var offset = reference.offset();
			position = {
				'left': offset.left - o,
				'top': offset.top + reference.height() - o,
			}
		}
		for(var key in map) {
			attr = key == 'left'? 'width': 'height';
			if(position[key] < o) {
				position[key] = o
			}
			if(position[key] + size[attr] + o > docSize[attr]) {
				position[key] = docSize[attr] - o - size[attr];
			}
		}
		$('div.contextmenu').hide();
		menu.css({
			'left': position.left,
			'top': position.top
		}).removeClass('fadeOutUp').addClass('fadeInDown').show(0, function() {
			$(this).find('a:first').focus();
		});
		src.on('mousewheel.conu', function() {
			return false;
		});
		$(document.body).one('click', function() {
			menu.removeClass('fadeInDown').addClass('fadeOutUp').hide(200);
			src.off('mousewheel.conu');
		});
	}
}

Page.mask = new function() {
	var count = 0;
	var id = 'page-mask';
	var create = function() {
		var mask = $('#' + id);
		if(mask.length == 0) {
			mask = $([
				'<div id="', id, '" class="mask" style="display: none;"></div>'
			].join(''));
			mask.appendTo(document.body);
		}
		return mask;
	}

	this.show = function() {
		if(count == 0) {
			create().show();
		}
		count++;
	}

	this.hide = function() {
		count--;
		if(count <= 0) {
			create().hide();
			count = 0;
		} 
	}
}();

Page.Dialog = function(content) {
	var index = (Page.Dialog.increment || 0) + 1;
	var duration = 500;

	var create = function() {
		var w = $([
			'<div id="dialog-' + index + '" class="dialog" style="display: none;">',
				'<div class="dialog-main">',
					'<div class="dialog-head">',
						'<div class="dialog-title"></div>',
						'<i class="dialog-close icon-remove"></i>',
					'</div>',
					'<div class="dialog-body"></div>',
					'<div class="dialog-foot"></div>',
				'</div>',
			'</div>'
		].join(''));
		w.find('div.dialog-body:first').append($(content).show());
		w.find('div.dialog-head:first').mousedown(move);
		w.find('i.dialog-close:first').click(close).mousedown(function() {
			return false;
		});
		w.appendTo('#lx');
	}

	var getElement = function(name) {
		return name?
			$('#dialog-' + index + ' div.dialog-' + name):
			$('#dialog-' + index);
	}

	var close = function() {
		var element = getElement();
		element.animate({
			'marginLeft': '100%'
		}, duration, function() {
			$(this).hide();
			Page.mask.hide();
		});
		Page.Dialog.last && focus(Page.Dialog.last);
	}

	var open = function() {
		var element = getElement();
		var size = element.size();
		var margin = {
			'marginLeft': 0 - parseInt(size.width / 2, 10),
			'marginTop': 0 - parseInt(size.height / 2, 10)
		}
		Page.mask.show();
		element.css({
			'marginTop': margin.marginTop,
			'marginLeft': '-100%',
			'display': 'block'
		}).animate({'marginLeft': margin.marginLeft}, duration);
		focus();
	}

	var move = function(event) {
		var element = getElement();
		var position = element.position();
		var xy = {
			'x': event.pageX,
			'y': event.pageY
		}
		var docSize = {
			'width': document.documentElement.clientWidth - 5,
			'height': document.documentElement.clientHeight - 5
		}
		var size = element.size();
		var oTop = Math.ceil(size.height / 2);
		var oLeft = Math.ceil(size.width / 2);
		element.removeClass('animated-200');
		$(window).on('mousemove.dialog', function(event) {
			var left = position.left + (event.pageX - xy.x);
			var top = position.top + (event.pageY - xy.y);
			if(left < oLeft) {
				left = oLeft + 5;
			} else if(left + size.width > docSize.width + oLeft) {
				left = docSize.width - size.width + oLeft;
			}
			if(top < oTop) {
				top = oTop + 5;
			} else if(top + size.height > docSize.height + oTop) {
				top = docSize.height - size.height + oTop;
			}
			element.css({
				'left': left,
				'top': top
			});
			return false;
		}).on('mouseup.dialog', function() {
			$(window).off('.dialog');
		});
		return false;
	}

	var focus = function(idx) {
		if(Page.Dialog.current) {
			$('#dialog-' + Page.Dialog.current).removeClass('active');
			Page.Dialog.last = Page.Dialog.current;
			Page.Dialog.current = null;
		}
		if(idx == undefined) {
			idx = index;
		}
		$('#dialog-' + idx).addClass('active');
		Page.Dialog.current = idx;
	}

	this.index = index;
	Page.Dialog.increment = index;

	this.open = function (title, fn) {
		getElement('title').html(title);
		open();
		fn && fn.call(this);
	}

	this.close = function() {
		close();
		fn && fn.call(this);
	}

	create();
}


$.fn.extend({
	size: function() {
		var css = {
			'display': this.css('display'),
			'visibility': this.css('visibility')
		}
		var size;
		this.css({'visibility': 'hidden', 'display': 'block'});
		size = {
			'width': this.width(), 
			'height': this.height()
		}
		this.css(css);
		return size;
	},

	addAnimation: function(name, duration) {
		var className = 'animated';
		if(duration) {
			className += '-' + duration;
		}
		className = [className, name].join(' ');
		this.addClass(className);
		setTimeout($.proxy(function() {
			this.removeClass(className);
		}, this), 1300);
		return this;
	},

	contextmenu: function(menu) {
		menu = $(menu);
		Page.contextMenu.setup(menu);
		return this.off('contextmenu.conu').on('contextmenu.conu', function(event) {
			Page.contextMenu.show(event, $(this), menu);
			return false;
		});
	},

	tabs: function() {
		this.find('nav.tabs>a').off('click.tabs').on('click.tabs', function() {
			var current = $(this);
			var contents = current.parent().next().children()
			var items = current.parent().children();
			var active = items.filter('.active');
			var currentIndex = items.index(current);
			var activeIndex = items.index(active);
			active.removeClass('active');
			current.addClass('active');
			contents.eq(activeIndex).hide();
			contents.eq(currentIndex).fadeIn();
		});
	},
	
	ajax: function(callback) {
		callback = callback || $.noop;
		return this.off('click.ajax').on('click.ajax', function(event, fn) {
			var target = this.getAttribute('target');
			var targetElement = $('#' + this.getAttribute('target'));
			var href = this.getAttribute('href');
			var script = this.getAttribute('script');
			var duration = 200;
			if(href && href != 'javascript:;') {
				var id = 'page-' + href.split('.')[0].replace(/\//g, '-');
				var div = $('#' + id);
				if(div.length == 0) {
					div = $('<div id="' + id + '" class="content-box"></div>');
					div.hide();
					div.appendTo(targetElement);
				}
				var status = div.attr('status');
				if(!div.attr('status')) {
					var load = function() {
						$.ajax({
							url: href,
							dataType: 'html',
							success: function(content) {
								div.html(content);
							},
							error: function(jqXHR, text, status) {
								div.html(jqXHR.responseText);
							}, 
							complete: function() {
								div.attr('status', 'loaded');
								targetElement.find('div.content-box:visible').hide(0);
								div.fadeIn(duration);
								callback.call(this);
								fn && fn.call(this);
							}
						});
					}

					div.attr('status', 'loading');
					if(script) {
						Page.loadScript({
							test: 'Contact',
							src: script,
							onload: load
						});
					} else {
						load();
					}
				} else if(status == 'loaded') {
					targetElement.find('div.content-box:visible').hide(0);
					div.fadeIn(duration);
					callback.call(this);
					fn && fn.call(this);
				}
			}
			event.preventDefault();
		});
	}
});
var Softphone = new function() {
	this.dialup = function() {
		$('#nav-dialup-lnk').trigger('click', [function() {
			$('#dialtime').html('00:00');
		}]);
	}
}();
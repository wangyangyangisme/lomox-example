var Contacts = new function() {
	var group = function(data) {
		var rs = {}
		var groupName;
		for(var i=0, l=data.length; i<l; i++) {
			groupName = data[i].group || 'Default';
			if(!rs[groupName]) {
				rs[groupName] = [];
			}
			rs[groupName].push(data[i]);
		}
		return rs;
	}

	this.getData = function() {
		return [
			{'id': 1, 'pic': 'user1.png', 'name': 'Anstice', 'number': '011-7776 6754', 'title': 'Windows Developer'},
			{'id': 2, 'pic': 'user2.png', 'name': 'Shawken', 'number': '021-5667 3346', 'title': 'Windows Developer', 'group': 'LomoX'},
			{'id': 3, 'pic': 'user2.png', 'name': 'Gennifer Gates', 'number': '0766-4689 3346', 'title': 'Windows Developer', 'group': 'Friend'},
			{'id': 4, 'pic': '', 'name': 'Steve Jobs', 'number': '0887-6234 6783', 'title': 'Windows Developer', 'group': 'LomoX'},
			{'id': 5, 'pic': 'user1.png', 'name': 'Howard', 'number': '0669-6234 1235', 'title': 'Windows Developer', 'group': 'LomoX'},
			{'id': 6, 'pic': 'user1.png', 'name': 'Alexandra', 'number': '0756-6234 3345', 'title': 'Windows Developer', 'group': 'Friend'},
			{'id': 7, 'pic': 'user2.png', 'name': 'Michael', 'number': '0766-4456 1367', 'title': 'Windows Developer', 'group': 'LomoX'},
			{'id': 8, 'pic': '', 'name': 'Nathan', 'number': '0757-5645 8887', 'title': 'Windows Developer', 'group': 'LomoX'},
			{'id': 9, 'pic': 'user1.png', 'name': 'Robinson', 'number': '0755-2356 7754', 'title': 'Windows Developer', 'group': 'LomoX'},
			{'id': 10, 'pic': '', 'name': 'Michael Jackson', 'number': '020-3456 3346', 'title': 'Windows Developer', 'group': 'Friend'},
			{'id': 12, 'pic': 'user1.png', 'name': 'Daniel', 'number': '010-6234 1345', 'title': 'Windows Developer', 'group': 'Friend'},
			{'id': 13, 'pic': 'user1.png', 'name': 'Anstice', 'number': '011-7776 6754', 'title': 'Windows Developer', 'group': 'Friend'},
			{'id': 14, 'pic': 'user2.png', 'name': 'Cortney', 'number': '011-4435 2234', 'title': 'Windows Developer', 'group': 'Friend'},
			{'id': 15, 'pic': 'user2.png', 'name': 'Gabriel', 'number': '021-6234 6954', 'title': 'Windows Developer', 'group': ''},
			{'id': 16, 'pic': '', 'name': 'Garland', 'number': '028-2345 8989', 'title': 'Windows Developer'},
			{'id': 17, 'pic': '', 'name': 'MacDonald', 'number': '0883-3457 7869', 'title': 'Windows Developer', 'group': 'LomoX'},
			{'id': 18, 'pic': 'user2.png', 'name': 'Quentin Garland', 'number': '0566-6234 8889', 'title': 'Windows Developer'},
			{'id': 19, 'pic': 'user1.png', 'name': 'Gallagher', 'number': '0335-7689 9997', 'title': 'Windows Developer', 'group': ''},
			{'id': 20, 'pic': 'user1.png', 'name': 'Wally Wallace', 'number': '011-0987 1118', 'title': 'Windows Developer', 'group': ''},
			{'id': 21, 'pic': '', 'name': 'Waldron Garland', 'number': '020-0000 5211', 'title': 'Windows Developer', 'group': 'LomoX'},
			{'id': 22, 'pic': 'user2.png', 'name': 'Maddox Daniel', 'number': '021-9807 3789', 'title': 'Windows Developer', 'group': 'LomoX'},
			{'id': 23, 'pic': 'user1.png', 'name': 'Waldron', 'number': '020-1208 3355', 'title': 'Windows Developer', 'group': ''},
			{'id': 24, 'pic': 'user1.png', 'name': 'Madeline', 'number': '020-6608 3535', 'title': 'Windows Developer', 'group': ''}
		];
	}

	this.getDataById = function(cid) {
		var data = this.getData();
		var rs = null;
		for(var i=0, l=data.length; i<l; i++) {
			if(cid == data[i].id) {
				rs = data[i];
				break;
			}
		}
		return rs;
	}

	this.gridView = function(target) {
		var html = [];
		var span, label;
		var data = this.getData();
		for(var i=0, t, l=data.length; i<l; i++) {
			t = parseInt(Math.random() * 3, 10);
			if(!data[i].pic) {
				span = '<i class="icon-user"></i>';
			} else {
				span = '<img src="css/img/' + data[i].pic + '" />';
			}
			label = data[i].name;
			html.push([
				'<a href="javascript:;" class="contacts-gridview-link" cid="' + data[i].id + '">',
					'<i class="icon-minus-sign"></i>',
					'<span>' + span + '</span>',
					'<label>' + Page.escapeHTML(label) + '</label>',
				'</a>'
			].join(''));
		}
		html.push('<div class="qt-placeholder"></div>');

		var content = $(html.join(''));
		content.find('i.icon-minus-sign').click(function() {
			var parent = $(this).parent();
			parent.addClass('animated-200 bounceOut');
			setTimeout(function() {
				parent.remove();
			}, 300);
		});
		content.find('label, span').click(function(event) {
			var link = $(this).parent();
			Contacts.showNameCard(event, link);
		});
		content.addClass('animated fadeInDown');

		$(target).html(content).parent().addClass('gridview');
	}

	this.listView = function(target) {
		var html = [];
		var data = group(this.getData());
		var groupName, i, l, contact;
		html.push('<table id="contacts-listview" class="grid" width="100%">');
		for(groupName in data) {
			html.push([
				'<tr class="contacts-listview-group">',
					'<td width="20" align="center"><i class="icon-caret-right"></i></td>',
					'<td>', Page.escapeHTML(groupName), ' [' + data[groupName].length + ']', '</td>',
					'<td width="40">',
						'<i class="icon-list-ul"></i> ',
						'<i class="icon-caret-down"></i>',
					'</td>',
				'</tr>'
			].join(''));
			html.push('<tr style="display: none;"><td colspan="3">');

			html.push('<table class="animated" width="100%">');
			for(i=0, l=data[groupName].length; i<l; i++) { 
				contact = data[groupName][i];
				html.push([
					'<tr>',
						'<td width="20">&nbsp;</td>',
						'<td width="24" align="center">', 
							contact.pic? 
								'<img src="css/img/' + contact.pic + '" class="pic" />':
								'<i class="icon-user"></i><i class="icon-play-circle"></i>',
						'</td>',
						'<td class="contacts-listview-name" cid="' + contact.id + '">',
							'&nbsp; ' + Page.escapeHTML(contact.name), 
						'</td>',
						'<td width="100">',
							'<div class="contacts-number">' + Page.escapeHTML(contact.number) + '</div>',
							'<div class="contacts-action">',
								'<i class="icon-film"></i> &nbsp;',
								'<i class="icon-star"></i> &nbsp;',
								'<i class="icon-trash"></i>',
							'</div>',
						'</td>',
					'</tr>'
				].join(''));
			}
			html.push('</table>');
			html.push('</td></tr>');
		}
		html.push('</table>');

		var table = $(html.join(''));
		table.find('tr.contacts-listview-group').click(function() {
			var tr = $(this);
			if(!tr.hasClass('expanded')) {
				tr.next().css('display', 'table-row').find('table').addClass('fadeInDown');
				tr.addClass('expanded');
			} else {
				tr.next().css('display', 'none').find('table').removeClass('fadeInDown');
				tr.removeClass('expanded');
			}
		});
		table.find('td.contacts-listview-name').on('click', function(event) {
			var td = $(this);
			Contacts.showNameCard(event, td);
		});
		$(target).empty().append(table).parent().removeClass('gridview');

		table.find('tr.contacts-listview-group:first').click();
		$('#contacts-gridview-minus').trigger('click', [true]);
	}

	this.showNameCard = function(event, src) {
		var id = src.attr('cid');
		var contact = Contacts.getDataById(id);
		var menu = $('#contacts-card');
		if(contact) {
			setTimeout(function() {
				if(contact.pic) {
					$('#contacts-card-pic').html('<img src="css/img/' + contact.pic + '" />');
				} else {
					$('#contacts-card-pic').html('<i class="icon-user"></i>');
				}
				$('#contacts-card-name').html(contact.name);
				$('#contacts-card-number').html('Phone: ' + (contact.number || ''));
				$('#contacts-card-email').html('Email: ' + (contact.email || ''));
				Page.contextMenu.setup(menu);
				Page.contextMenu.show(event, src, menu, src);
			}, 0);
		}
	}

	var contactDialog;
	this.addContact = function() {
		var clickFirst = false;
		if(!contactDialog) {
			contactDialog = new Page.Dialog('#contacts-dialog');
			$('#contacts-dialog').tabs();
			$('#contacts-dialog>nav>a:first').click();
			clickFirst = true;
		}
		contactDialog.open('Add Contact', function() {
			!clickFirst && $('#contacts-dialog>nav>a:first').click();
			$('#contact-form-username').focus();
		});
	}

	var contactCardDialog;
	this.addContactCard = function() {
		if(!contactCardDialog) {
			contactCardDialog = new Page.Dialog('#contacts-card-form');
		}
		contactCardDialog.open('Add list', function() {
			$('listname').focus();
		});
	}
}();